import { Component } from '@angular/core';
import { Observable, map, interval } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'lab-act';

  /*time$: Observable<Date>;
  constructor(){
    this.time$ = interval(1000).pipe(map(()=> new Date()));
  }*/


  //date pipe
  presentDate = new Date();

  ngOnInit(){}
  
  //currency-pipes
  priceMango : number = 100;
  priceApple: number = 50;
  priceOrange: number = 25;

  //slice-pipes
  Fruits = ["Apple", "Orange", "Mango"]; 
  
  //percent pipes
  a : number = 0.259;
  b : number = 0.10;
  c : number = 0.05;

  //JSON
  object: Object = {name: 'Renz', num: '15', AboutMe: {Podium: 3, Favorites: 
    ["racing", "games", "coding"]}};

  //Text format
  text1 : string = 'Basta Orange Prut';
  text2 : string = 'Basta Mango Prut';
  text3 : string = 'Basta Apple Prut';

  //Decimal pipes
  deciNum1 : number = 3.14;
  deciNum2 : number = 0.15;
  deciNum3 : number = 99.9;

}
